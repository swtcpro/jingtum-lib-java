package com.blink.bouncycastle.asn1;

public interface ASN1String
{
    public String getString();
}
