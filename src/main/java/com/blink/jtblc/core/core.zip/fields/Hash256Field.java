package com.blink.jtblc.core.fields;

public abstract class Hash256Field implements HasField {}
