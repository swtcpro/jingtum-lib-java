package com.blink.jtblc.core.fields;

public abstract class Hash128Field implements HasField {}
