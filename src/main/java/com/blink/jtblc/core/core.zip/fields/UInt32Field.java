package com.blink.jtblc.core.fields;

public abstract class UInt32Field implements HasField {}
