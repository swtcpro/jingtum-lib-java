package com.blink.jtblc.core.fields;

public abstract class UInt8Field implements HasField {}
