package com.blink.jtblc.core.coretypes.hash.prefixes;

public interface Prefix {
    byte[] bytes();
}
