package com.blink.jtblc.core.fields;

public abstract class Vector256Field implements HasField{}
