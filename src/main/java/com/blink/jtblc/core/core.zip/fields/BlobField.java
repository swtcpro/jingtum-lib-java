package com.blink.jtblc.core.fields;

public abstract class BlobField implements HasField{}
