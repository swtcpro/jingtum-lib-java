package com.blink.jtblc.core.fields;

public abstract class AccountIDField implements HasField {}
