package com.blink.jtblc.core.fields;

public abstract class PathSetField implements HasField{}
