package com.blink.jtblc.core.fields;

public interface HasField {
    Field getField();
}
