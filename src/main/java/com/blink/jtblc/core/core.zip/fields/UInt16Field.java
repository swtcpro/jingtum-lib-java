package com.blink.jtblc.core.fields;

public abstract class UInt16Field implements HasField {}
