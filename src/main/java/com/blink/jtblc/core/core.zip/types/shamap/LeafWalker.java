package com.blink.jtblc.core.types.shamap;

public interface LeafWalker {
    void onLeaf(ShaMapLeaf shaMapLeaf);
}
